﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace McKessonProgrammingTest.Models
{
    [Table("PartTimeEmployee")]
    public partial class PartTimeEmployee
    {
        /// <summary>
        /// Part-Time Employee Id
        /// </summary>
        [Key]
        [Display(Name = "Part-Time Employee Id")]
        public int EmployeeId { get; set; }
    }
}
