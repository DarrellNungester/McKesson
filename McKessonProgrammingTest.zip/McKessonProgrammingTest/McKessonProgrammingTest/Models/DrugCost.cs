﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace McKessonProgrammingTest.Models
{
    [Table("DrugCost")]
    public partial class DrugCost
    {
        /// <summary>
        /// Drug Cost ID
        /// </summary>
        [Key]
        [Column("DrugCostID")]
        [Display(Name = "Drug Cost ID")]
        public int DrugCostId { get; set; }

        /// <summary>
        /// Drug ID
        /// </summary>
        [Column("DrugID")]
        [Display(Name = "Drug ID")]
        public int DrugId { get; set; }

        /// <summary>
        /// Effective Date
        /// </summary>
        [Column(TypeName = "date")]
        [Display(Name = "Effective Date")]
        public DateTime EffectiveDate { get; set; }

        /// <summary>
        /// Cost
        /// </summary>
        [Column(TypeName = "money")]
        [Display(Name = "Cost")]
        public decimal Cost { get; set; }
    }
}
