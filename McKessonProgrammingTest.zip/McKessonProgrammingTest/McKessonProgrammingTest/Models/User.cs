﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace McKessonProgrammingTest.Models
{
    [Table("User")]
    public partial class User
    {
        /// <summary>
        /// User ID
        /// </summary>
        [Key]
        [Column("UserID")]
        [Display(Name = "User ID")]
        public int UserId { get; set; }

        /// <summary>
        /// Username 
        /// </summary>
        [Display(Name = "Username")]
        [StringLength(50)]
        [Unicode(false)]
        public string Username { get; set; } = null!;

        /// <summary>
        /// First Name 
        /// </summary>
        [Display(Name = "First Name")]
        [StringLength(50)]
        [Unicode(false)]
        public string FirstName { get; set; } = null!;

        /// <summary>
        /// Last Name 
        /// </summary>
        [Display(Name = "Last Name")]
        [StringLength(50)]
        [Unicode(false)]
        public string LastName { get; set; } = null!;
    }
}
