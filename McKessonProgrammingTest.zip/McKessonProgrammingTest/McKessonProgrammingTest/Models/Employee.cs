﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace McKessonProgrammingTest.Models
{
    [Table("Employee")]
    public partial class Employee
    {
        /// <summary>
        /// Employee Id
        /// </summary>
        [Key]
        [Display(Name = "Employee Id")]
        public int EmployeeId { get; set; }

        /// <summary>
        /// Employee Name
        /// </summary>
        [Display(Name = "Employee Name")]
        [StringLength(100)]
        [Unicode(false)]
        public string EmployeeName { get; set; } = null!;
    }
}
