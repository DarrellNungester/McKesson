﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace McKessonProgrammingTest.Models
{
    [Table("Revenue")]
    public partial class Revenue
    {
        /// <summary>
        /// Revenue Id
        /// </summary>
        [Key]
        [Display(Name = "Revenue Id")]
        public int RevenueId { get; set; }

        /// <summary>
        /// Facility
        /// </summary>
        [Display(Name = "Facility")]
        [StringLength(50)]
        [Unicode(false)]
        public string Facility { get; set; } = null!;

        /// <summary>
        /// Revenue Month
        /// </summary>
        [Display(Name = "Revenue Month")]
        public int Month { get; set; }

        /// <summary>
        /// Revenue Year
        /// </summary>
        [Display(Name = "Revenue Year")]
        public int Year { get; set; }

        /// <summary>
        /// Revenue
        /// </summary>
        [Column("Revenue", TypeName = "money")]
        [Display(Name = "Revenue")]
        public decimal Revenue1 { get; set; }
    }
}
