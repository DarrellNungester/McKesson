﻿using Microsoft.EntityFrameworkCore;
using McKessonProgrammingTest.Models;

namespace McKessonProgrammingTest.Data
{
    public partial class CoreDbContext : DbContext
    {
        public CoreDbContext()
        {
        }

        public CoreDbContext(DbContextOptions<CoreDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<DrugCost> DrugCosts { get; set; } = null!;

        public virtual DbSet<Employee> Employees { get; set; } = null!;

        public virtual DbSet<PartTimeEmployee> PartTimeEmployees { get; set; } = null!;

        public virtual DbSet<Revenue> Revenues { get; set; } = null!;

        public virtual DbSet<User> Users { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DrugCost>(entity =>
            {
                entity.Property(e => e.DrugCostId).HasComment("Drug Cost ID");

                entity.Property(e => e.Cost).HasComment("Cost");

                entity.Property(e => e.DrugId).HasComment("Drug ID");

                entity.Property(e => e.EffectiveDate).HasComment("Effective Date");
            });

            modelBuilder.Entity<Employee>(entity =>
            {
                entity.Property(e => e.EmployeeId)
                    .ValueGeneratedNever()
                    .HasComment("Employee Id");

                entity.Property(e => e.EmployeeName).HasComment("Employee Name");
            });

            modelBuilder.Entity<PartTimeEmployee>(entity =>
            {
                entity.Property(e => e.EmployeeId)
                    .ValueGeneratedNever()
                    .HasComment("Part-Time Employee Id");
            });

            modelBuilder.Entity<Revenue>(entity =>
            {
                entity.Property(e => e.RevenueId).HasComment("Revenue Id");

                entity.Property(e => e.Facility).HasComment("Facility");

                entity.Property(e => e.Month).HasComment("Month");

                entity.Property(e => e.Revenue1).HasComment("Revenue");

                entity.Property(e => e.Year).HasComment("Year");
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.Property(e => e.UserId).HasComment("User ID");

                entity.Property(e => e.FirstName).HasComment("First Name ");

                entity.Property(e => e.LastName).HasComment("Last Name ");

                entity.Property(e => e.Username).HasComment("Username ");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
