﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using McKessonProgrammingTest.Data;
using McKessonProgrammingTest.Models;

namespace McKessonProgrammingTest.Controllers
{
    public class PartTimeEmployeesController : Controller
    {
        private readonly CoreDbContext _context;

        public PartTimeEmployeesController(CoreDbContext context)
        {
            _context = context;
        }

        // GET: PartTimeEmployees

        public async Task<IActionResult> Index()
        {
              return _context.PartTimeEmployees != null ? 
                          View(await _context.PartTimeEmployees.ToListAsync()) :
                          Problem("Entity set 'CoreDbContext.PartTimeEmployees'  is null.");
        }

        // GET: PartTimeEmployees/Details/5

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.PartTimeEmployees == null)
            {
                return NotFound();
            }

            var partTimeEmployee = await _context.PartTimeEmployees
                .FirstOrDefaultAsync(m => m.EmployeeId == id);

            if (partTimeEmployee == null)
            {
                return NotFound();
            }

            return View(partTimeEmployee);
        }

        // GET: PartTimeEmployees/Create

        public IActionResult Create()
        {
            return View();
        }

        // POST: PartTimeEmployees/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("EmployeeId")] PartTimeEmployee partTimeEmployee)
        {
            if (ModelState.IsValid)
            {
                _context.Add(partTimeEmployee);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            return View(partTimeEmployee);
        }

        // GET: PartTimeEmployees/Delete/5

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.PartTimeEmployees == null)
            {
                return NotFound();
            }

            var partTimeEmployee = await _context.PartTimeEmployees
                .FirstOrDefaultAsync(m => m.EmployeeId == id);

            if (partTimeEmployee == null)
            {
                return NotFound();
            }

            return View(partTimeEmployee);
        }

        // POST: PartTimeEmployees/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.PartTimeEmployees == null)
            {
                return Problem("Entity set 'CoreDbContext.PartTimeEmployees'  is null.");
            }

            var partTimeEmployee = await _context.PartTimeEmployees.FindAsync(id);

            if (partTimeEmployee != null)
            {
                _context.PartTimeEmployees.Remove(partTimeEmployee);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PartTimeEmployeeExists(int id)
        {
          return (_context.PartTimeEmployees?.Any(e => e.EmployeeId == id)).GetValueOrDefault();
        }
    }
}
