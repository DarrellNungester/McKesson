﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using McKessonProgrammingTest.Data;
using McKessonProgrammingTest.Models;

namespace McKessonProgrammingTest.Controllers
{
    public class RevenuesController : Controller
    {
        private readonly CoreDbContext _context;

        public RevenuesController(CoreDbContext context)
        {
            _context = context;
        }

        // GET: Revenues

        public async Task<IActionResult> Index()
        {
              return _context.Revenues != null ? 
                          View(await _context.Revenues.ToListAsync()) :
                          Problem("Entity set 'CoreDbContext.Revenues'  is null.");
        }

        // GET: Revenues/Details/5

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Revenues == null)
            {
                return NotFound();
            }

            var revenue = await _context.Revenues
                .FirstOrDefaultAsync(m => m.RevenueId == id);

            if (revenue == null)
            {
                return NotFound();
            }

            return View(revenue);
        }

        // GET: Revenues/Create

        public IActionResult Create()
        {
            return View();
        }

        // POST: Revenues/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("RevenueId,Facility,Month,Year,Revenue1")] Revenue revenue)
        {
            if (ModelState.IsValid)
            {
                _context.Add(revenue);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            return View(revenue);
        }

        // GET: Revenues/Edit/5

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Revenues == null)
            {
                return NotFound();
            }

            var revenue = await _context.Revenues.FindAsync(id);

            if (revenue == null)
            {
                return NotFound();
            }

            return View(revenue);
        }

        // POST: Revenues/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("RevenueId,Facility,Month,Year,Revenue1")] Revenue revenue)
        {
            if (id != revenue.RevenueId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(revenue);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!RevenueExists(revenue.RevenueId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return RedirectToAction(nameof(Index));
            }

            return View(revenue);
        }

        // GET: Revenues/Delete/5

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Revenues == null)
            {
                return NotFound();
            }

            var revenue = await _context.Revenues
                .FirstOrDefaultAsync(m => m.RevenueId == id);

            if (revenue == null)
            {
                return NotFound();
            }

            return View(revenue);
        }

        // POST: Revenues/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Revenues == null)
            {
                return Problem("Entity set 'CoreDbContext.Revenues'  is null.");
            }

            var revenue = await _context.Revenues.FindAsync(id);

            if (revenue != null)
            {
                _context.Revenues.Remove(revenue);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool RevenueExists(int id)
        {
          return (_context.Revenues?.Any(e => e.RevenueId == id)).GetValueOrDefault();
        }
    }
}
