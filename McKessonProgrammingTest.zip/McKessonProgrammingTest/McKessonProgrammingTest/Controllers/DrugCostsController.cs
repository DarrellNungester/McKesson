﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using McKessonProgrammingTest.Data;
using McKessonProgrammingTest.Models;

namespace McKessonProgrammingTest.Controllers
{
    public class DrugCostsController : Controller
    {
        private readonly CoreDbContext _context;

        public DrugCostsController(CoreDbContext context)
        {
            _context = context;
        }

        // GET: DrugCosts

        public async Task<IActionResult> Index()
        {
              return _context.DrugCosts != null ? 
                          View(await _context.DrugCosts.ToListAsync()) :
                          Problem("Entity set 'CoreDbContext.DrugCosts'  is null.");
        }

        // GET: DrugCosts/Details/5

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.DrugCosts == null)
            {
                return NotFound();
            }

            var drugCost = await _context.DrugCosts
                .FirstOrDefaultAsync(m => m.DrugCostId == id);

            if (drugCost == null)
            {
                return NotFound();
            }

            return View(drugCost);
        }

        // GET: DrugCosts/Create

        public IActionResult Create()
        {
            return View();
        }

        // POST: DrugCosts/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("DrugCostId,DrugId,EffectiveDate,Cost")] DrugCost drugCost)
        {
            if (ModelState.IsValid)
            {
                _context.Add(drugCost);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            return View(drugCost);
        }

        // GET: DrugCosts/Edit/5

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.DrugCosts == null)
            {
                return NotFound();
            }

            var drugCost = await _context.DrugCosts.FindAsync(id);

            if (drugCost == null)
            {
                return NotFound();
            }

            return View(drugCost);
        }

        // POST: DrugCosts/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("DrugCostId,DrugId,EffectiveDate,Cost")] DrugCost drugCost)
        {
            if (id != drugCost.DrugCostId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(drugCost);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DrugCostExists(drugCost.DrugCostId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return RedirectToAction(nameof(Index));
            }

            return View(drugCost);
        }

        // GET: DrugCosts/Delete/5

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.DrugCosts == null)
            {
                return NotFound();
            }

            var drugCost = await _context.DrugCosts
                .FirstOrDefaultAsync(m => m.DrugCostId == id);

            if (drugCost == null)
            {
                return NotFound();
            }

            return View(drugCost);
        }

        // POST: DrugCosts/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.DrugCosts == null)
            {
                return Problem("Entity set 'CoreDbContext.DrugCosts'  is null.");
            }

            var drugCost = await _context.DrugCosts.FindAsync(id);

            if (drugCost != null)
            {
                _context.DrugCosts.Remove(drugCost);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool DrugCostExists(int id)
        {
          return (_context.DrugCosts?.Any(e => e.DrugCostId == id)).GetValueOrDefault();
        }
    }
}
